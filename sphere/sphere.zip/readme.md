# Sphere implemented in glut
## Get started
To install dependencies paste the following commands in console
```
sudo apt-get install freeglut3 freeglut3-dev
sudo apt-get install binutils-gold
```

## Execute
To build and execute the program run
```
cd src && make && cd ..
cd ./sphere 
```